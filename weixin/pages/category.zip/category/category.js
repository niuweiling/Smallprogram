// pages/category/category.js
import { SUCCESS, FAIL, HOSTNAME, IMGHOSTNAME} from "../../config/base.js";
import {api} from "../../config/promise.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    catelist:[],
    goods: [],
  },

 

  /**
   * 生命周期函数--监听页面加载
   */

  // 获取商品分类信息
  querycate(){
          api('GET', '/api/index')
          .then(res => {
            //请求成功
            let categoods = res.data;
            // 设置catelist的值
            this.setData({
              catelist: categoods,
            })
          })
  },

  // 获取分类下的商品信息
  getcategoods() {
    api('GET', '/api/index')
      .then(res => {
        //请求成功
          let categoods = res.data;
          for (let i = 0; i < categoods.length; i++) {
            // categoods[i].thumb = IMGHOSTNAME+ categoods[i].thumb.replace(/\\/, '/');

            // 改变商品中图片的路径
            for (let j = 0; j < categoods[i].goods.length; j++) {
              categoods[i].goods[j].thumb = IMGHOSTNAME + categoods[i].goods[j].thumb.replace(/\\/, '/');
              // console.log(categoods[i].goods[j].thumb);
            }
          };

          // 设置catelist的值
          this.setData({
            goods: categoods,
          })
     
      })
  },

  onLoad: function (options) {
    this.querycate();
    this.getcategoods();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})